interface PaymentProcessor {
    boolean processPayment(Transaction transaction);
}