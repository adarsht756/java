package Model;
public class RecordEntity {
    public String entityName;
    public Object entityValue;

    public RecordEntity(String entityName, Object entityValue) {
        this.entityName = entityName;
        this.entityValue = entityValue;
    }
}