package Model;
public abstract class Constraint {
    public abstract Boolean validate(Object v);
}