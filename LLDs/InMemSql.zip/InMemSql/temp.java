enum temp {
    Monday(1), SD(3);
    private int x;
    private temp(int x) {
        this.x = x;
    }
}